# Migration Guide: Moving to the Component-Based Website

This guide will help you transition from your current HTML website to the new component-based architecture.

## Step 1: Set Up Your Development Environment

1. **Clone the New Repository**
   ```bash
   git clone [your-new-repo-url]
   cd HLPFL-Modern
   ```

2. **Install VSCode Extensions** (recommended)
   - Live Server (for local development)
   - HTML CSS Support
   - JavaScript (ES6) code snippets

## Step 2: Understand the Directory Structure

```
HLPFL-Modern/
├── components/       # Reusable components
├── css/             # Stylesheets
├── js/              # JavaScript files
├── images/          # Image assets
├── index.html       # Homepage
├── about.html       # About page
├── services.html    # Services page
├── red-flag-guide.html  # Red Flag Guide page
└── README.md        # Documentation
```

## Step 3: Copy Your Content and Assets

1. **Copy Images**
   - Copy all images from your old site to the `images/` directory
   - Update image paths in the new HTML files if necessary

2. **Copy Custom Fonts**
   - If you have custom fonts, copy them to a new `fonts/` directory
   - Update font references in CSS

3. **Copy Additional Assets**
   - Copy any videos, PDFs, or other assets to appropriate directories

## Step 4: Customize the Components

1. **Header Component**
   - Open `components/header.html`
   - Update navigation links if needed
   - Replace the logo with your actual logo

2. **Footer Component**
   - Open `components/footer.html`
   - Update links, social media, and contact information
   - The year will automatically update (using `{{$currentYear}}`)

3. **Hero Component**
   - For each page, update the hero component properties in the HTML:
   ```html
   <div data-component="hero" 
        data-prop-video-src="images/your-video.mp4"
        data-prop-fallback-image="images/your-fallback.jpg"
        data-prop-title="Your Title"
        data-prop-subtitle="Your subtitle"></div>
   ```

4. **Other Components**
   - Review and update all other components as needed

## Step 5: Update Page Content

For each page (index.html, about.html, services.html, etc.):

1. **Review the Structure**
   - Understand how components are used on the page
   - Identify where your content needs to go

2. **Replace Content**
   - Replace placeholder text with your actual content
   - Update images and links
   - Keep the component structure intact

3. **Test the Page**
   - Use Live Server to preview the page
   - Check that all components load correctly
   - Verify that your content displays properly

## Step 6: Customize Styling

1. **Update Colors**
   - Open `css/base.css`
   - Modify the color variables to match your brand:
   ```css
   :root {
     --c-bg-primary: #000;
     --c-bg-secondary: #111;
     --c-accent: #144d63;
     /* other color variables */
   }
   ```

2. **Adjust Typography**
   - Update font families and sizes in `css/base.css`
   - Modify text styles as needed

3. **Customize Component Styles**
   - Make specific component style adjustments in `css/components.css`
   - Keep the component class names intact

## Step 7: Test Thoroughly

1. **Cross-Browser Testing**
   - Test in Chrome, Firefox, Safari, and Edge
   - Verify that all features work correctly

2. **Mobile Testing**
   - Test on various screen sizes
   - Ensure responsive behavior works as expected

3. **Performance Testing**
   - Check page load times
   - Verify that animations are smooth
   - Test video loading

## Step 8: Deploy to Cloudflare

1. **Prepare for Deployment**
   - Ensure all file paths are relative
   - Optimize images if needed
   - Verify all links work correctly

2. **Deploy to Cloudflare**
   - Log in to your Cloudflare account
   - Go to the Pages section
   - Create a new project or update your existing one
   - Upload your files or connect to your Git repository
   - Deploy the website

3. **Verify Deployment**
   - Check that all pages load correctly
   - Test all features on the live site
   - Verify that all links work

## Common Migration Challenges and Solutions

### Challenge: Component Not Loading
**Solution:** Check that the component file exists in the `components/` directory and that the `data-component` attribute is correct.

### Challenge: Styling Differences
**Solution:** Adjust the CSS in `css/components.css` or `css/base.css` to match your desired style.

### Challenge: JavaScript Errors
**Solution:** Check the browser console for errors and verify that all required scripts are included.

### Challenge: Video Not Playing
**Solution:** Ensure the video file exists and is in a supported format (MP4 recommended).

### Challenge: Mobile Layout Issues
**Solution:** Use the browser's developer tools to test different screen sizes and adjust CSS as needed.

## Need More Help?

If you encounter any issues during migration:

1. Check the detailed documentation in `README.md`
2. Review the component examples in the sample pages
3. Compare your implementation with the provided examples
4. Reach out for support if needed

## Next Steps After Migration

1. **Create Additional Pages**
   - Use the existing pages as templates
   - Reuse components to maintain consistency

2. **Add New Components**
   - Create new component files in the `components/` directory
   - Follow the existing component structure

3. **Enhance Functionality**
   - Add new features as needed
   - Extend the component system as your site grows

4. **Regular Updates**
   - Keep your content fresh
   - Update components as needed
   - Maintain consistent styling across the site