# HLPFL Co Website Modernization Guide

## What We've Done

We've completely modernized your website by implementing a component-based architecture. This approach allows you to build pages like Lego blocks, making maintenance and updates much easier.

### Key Improvements:

1. **Component-Based System**: Created reusable components (header, footer, hero, etc.) that can be used across all pages
2. **Performance Optimization**: Fixed mouse cursor performance issues and optimized animations
3. **Video Loading**: Improved hero video loading and overlay issues
4. **Consistent Design**: Ensured header and footer are consistent across all pages
5. **Mobile Responsiveness**: Fixed differences between mobile and desktop versions
6. **Loading Issues**: Resolved loading screen problems on about and services pages
7. **Visual Improvements**: Fixed spacing in red flag text and removed unwanted orange color on page breaks

## How to Use the New System

### Basic Page Structure

Every page follows this basic structure:

```html
<!DOCTYPE html>
<html lang="en">
<head>
  <!-- Meta tags, title, CSS links -->
</head>
<body class="page">
  <!-- Loading Component -->
  <div data-component="loading"></div>
  
  <!-- Custom Cursor Component -->
  <div data-component="cursor"></div>
  
  <!-- Header Component -->
  <div class="page__header" data-component="header"></div>
  
  <main class="page__main">
    <!-- Page content and components -->
  </main>
  
  <!-- Footer Component -->
  <div class="page__footer" data-component="footer"></div>
  
  <!-- Scripts -->
  <script src="js/component-loader.js"></script>
  <script src="js/main.js"></script>
</body>
</html>
```

### Using Components

To add a component to a page, use the `data-component` attribute:

```html
<div data-component="header"></div>
```

To pass properties to a component, use `data-prop-*` attributes:

```html
<div data-component="hero" 
     data-prop-title="Welcome to Our Site" 
     data-prop-subtitle="Learn more about our services"
     data-prop-video-src="images/hero-video.mp4"></div>
```

### Available Components

1. **Header** (`header.html`): Site navigation
   ```html
   <div class="page__header" data-component="header"></div>
   ```

2. **Footer** (`footer.html`): Site footer with links and copyright
   ```html
   <div class="page__footer" data-component="footer"></div>
   ```

3. **Hero** (`hero.html`): Hero section with video background
   ```html
   <div data-component="hero" 
        data-prop-video-src="images/hero-video.mp4"
        data-prop-fallback-image="images/hero-fallback.jpg"
        data-prop-alt-text="HLPFL Co Hero"
        data-prop-show-red-flag="true"
        data-prop-red-flag-text="Attention Founders"
        data-prop-title="Your Hero Title"
        data-prop-subtitle="Your subtitle goes here"
        data-prop-cta-text="Get Started"
        data-prop-cta-link="#services"></div>
   ```

4. **Service Card** (`service-card.html`): Card for displaying services
   ```html
   <div data-component="service-card"
        data-prop-image="images/service1.jpg"
        data-prop-title="Service Title"
        data-prop-description="Service description goes here."
        data-prop-link="services.html#details"></div>
   ```

5. **Loading** (`loading.html`): Loading/preloader screen
   ```html
   <div data-component="loading"></div>
   ```

6. **Custom Cursor** (`cursor.html`): Custom cursor with improved performance
   ```html
   <div data-component="cursor"></div>
   ```

7. **Red Flag Popup** (`red-flag-popup.html`): Popup for red flag content
   ```html
   <div data-component="red-flag-popup"
        data-prop-title="Red Flag Alert"
        data-prop-content="<p>Your content here</p>"
        data-prop-cta-text="Learn More"
        data-prop-cta-link="red-flag-guide.html"
        data-prop-show-on-mobile="true"></div>
   ```

## Creating New Pages

To create a new page:

1. Create a new HTML file in the root directory
2. Copy the basic structure from an existing page
3. Add your page-specific content
4. Include the components you need
5. Customize component properties as needed

## Modifying Components

If you need to modify a component:

1. Open the component file in the `components/` directory
2. Make your changes to the HTML structure
3. Update the CSS in `css/components.css` if needed

## Creating New Components

To create a new component:

1. Create a new HTML file in the `components/` directory
2. Define the component's HTML structure
3. Use `{{propertyName}}` for dynamic properties
4. Add any component-specific JavaScript
5. Add CSS for the component in `css/components.css`

## CSS Structure

The CSS is organized into several files:

- `base.css` - Reset, variables, and foundational styles
- `components.css` - Styles for reusable components
- `layout.css` - Page layouts and section styles
- `main.css` - Imports all other CSS files

## Next Steps

1. **Copy Your Content**: Transfer your existing content to the new component-based pages
2. **Update Images**: Replace placeholder images with your actual images
3. **Customize Colors**: Adjust the color variables in `css/base.css` to match your brand
4. **Test Thoroughly**: Test the website on different devices and browsers
5. **Deploy**: Upload the files to your Cloudflare hosting

## Need Help?

If you need assistance with the new component system, refer to the detailed README.md file or reach out for support.