# Getting Started with Your New Component-Based Website

This guide will help you quickly get up and running with your new component-based HLPFL Co website.

## Quick Start

1. **Clone the repository**
   ```bash
   git clone [your-repository-url]
   cd HLPFL-Modern
   ```

2. **Install dependencies** (optional, only needed for local development server)
   ```bash
   npm install
   ```

3. **Copy assets from old site**
   ```bash
   # If using npm
   npm run copy-assets
   
   # Or directly with bash
   ./copy-assets.sh ../path/to/old/site
   ```

4. **Start local development server** (optional)
   ```bash
   npm start
   ```

5. **Open in browser**
   If using the development server, open http://localhost:8080
   Otherwise, open the HTML files directly in your browser

## Key Files and Directories

- **`components/`**: Contains all reusable components
- **`css/`**: Contains all stylesheets
- **`js/`**: Contains JavaScript files
- **`images/`**: Place all your images here
- **`*.html`**: Main page files

## Documentation

We've provided several documentation files to help you:

1. **`README.md`**: Complete documentation of the component system
2. **`GUIDE.md`**: Quick guide to using the component system
3. **`COMPARISON.md`**: Comparison between old and new approaches
4. **`MIGRATION-GUIDE.md`**: Detailed steps for migrating content

## Common Tasks

### Creating a New Page

1. Copy an existing HTML file (e.g., `about.html`) to a new file
2. Update the title, meta tags, and content
3. Customize the components as needed

Example:
```html
<!DOCTYPE html>
<html lang="en">
<head>
  <title>New Page - HLPFL Co</title>
  <!-- Meta tags, CSS links, etc. -->
</head>
<body class="page">
  <!-- Loading Component -->
  <div data-component="loading"></div>
  
  <!-- Custom Cursor Component -->
  <div data-component="cursor"></div>
  
  <!-- Header Component -->
  <div class="page__header" data-component="header"></div>
  
  <main class="page__main">
    <!-- Your page content here -->
  </main>
  
  <!-- Footer Component -->
  <div class="page__footer" data-component="footer"></div>
  
  <!-- Scripts -->
  <script src="js/component-loader.js"></script>
  <script src="js/main.js"></script>
</body>
</html>
```

### Adding a Component to a Page

```html
<!-- Basic component -->
<div data-component="component-name"></div>

<!-- Component with properties -->
<div data-component="hero" 
     data-prop-title="My Page Title" 
     data-prop-subtitle="Page subtitle"></div>
```

### Updating the Header or Footer

1. Open `components/header.html` or `components/footer.html`
2. Make your changes
3. Save the file
4. The changes will automatically apply to all pages

### Changing Colors

1. Open `css/base.css`
2. Find the `:root` section with color variables
3. Update the color values to match your brand

```css
:root {
  --c-bg-primary: #000;
  --c-bg-secondary: #111;
  --c-accent: #144d63;
  /* other color variables */
}
```

## Deployment

To deploy your site to Cloudflare:

1. Ensure all files are ready for production
2. Log in to your Cloudflare account
3. Go to the Pages section
4. Create a new project or update your existing one
5. Upload your files or connect to your Git repository
6. Deploy the website

## Need Help?

If you need assistance:

1. Review the documentation files
2. Check the example pages for reference
3. Reach out for support if needed

## Next Steps

1. **Customize your content**: Replace placeholder text and images
2. **Update your branding**: Adjust colors, fonts, and styles
3. **Test thoroughly**: Check all pages on different devices
4. **Deploy**: Upload to your hosting provider
5. **Maintain**: Keep your content fresh and up-to-date