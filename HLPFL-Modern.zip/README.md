# HLPFL Co - Modern Component-Based Website

This is a modernized version of the HLPFL Co website using a component-based architecture. This approach allows you to build pages like Lego blocks, making maintenance and updates much easier.

## Table of Contents
- [Overview](#overview)
- [Getting Started](#getting-started)
- [Component System](#component-system)
- [Creating New Pages](#creating-new-pages)
- [Customizing Components](#customizing-components)
- [CSS Structure](#css-structure)
- [JavaScript Features](#javascript-features)
- [Deployment](#deployment)

## Overview

This website uses a custom component system that allows for:
- Reusable components across pages (header, footer, hero sections, etc.)
- Consistent styling and behavior
- Easier maintenance and updates
- Better performance and user experience

## Getting Started

1. Clone this repository to your local machine
2. Open the project in VSCode
3. Use a local server to preview the website (e.g., Live Server extension in VSCode)
4. Make changes to components, CSS, or JavaScript as needed
5. Deploy to your hosting provider (e.g., Cloudflare)

## Component System

### How Components Work

The component system uses a JavaScript-based approach to load HTML components into pages. Here's how it works:

1. Each component is defined in an HTML file in the `components/` directory
2. Pages include components using the `data-component` attribute
3. The component loader (`js/component-loader.js`) loads and renders components
4. Components can accept properties using `data-prop-*` attributes

### Available Components

- `header.html` - Site navigation header
- `footer.html` - Site footer with links and copyright
- `hero.html` - Hero section with video background
- `service-card.html` - Card for displaying services
- `loading.html` - Loading/preloader screen
- `cursor.html` - Custom cursor
- `red-flag-popup.html` - Popup for red flag content

### Component Example

To include a component in a page:

```html
<div data-component="header"></div>
```

To include a component with properties:

```html
<div data-component="hero" 
     data-prop-title="Welcome to Our Site" 
     data-prop-subtitle="Learn more about our services"
     data-prop-video-src="images/hero-video.mp4"></div>
```

## Creating New Pages

To create a new page:

1. Create a new HTML file in the root directory
2. Include the necessary head content (meta tags, CSS, etc.)
3. Add components using the `data-component` attribute
4. Add page-specific content as needed
5. Include the component loader and main script at the end of the body

Example:

```html
<!DOCTYPE html>
<html lang="en">
<head>
  <title>New Page - HLPFL Co</title>
  <meta name="description" content="Page description">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  
  <!-- Stylesheets -->
  <link rel="stylesheet" href="css/main.css">
  <!-- Other head content -->
</head>
<body class="page">
  <!-- Loading Component -->
  <div data-component="loading"></div>
  
  <!-- Custom Cursor Component -->
  <div data-component="cursor"></div>
  
  <!-- Header Component -->
  <div class="page__header" data-component="header"></div>
  
  <main class="page__main">
    <!-- Hero Component -->
    <div data-component="hero" 
         data-prop-title="New Page"
         data-prop-subtitle="Page subtitle"></div>
    
    <!-- Page-specific content -->
    <section class="section">
      <div class="container">
        <h2>Section Title</h2>
        <p>Section content</p>
      </div>
    </section>
  </main>
  
  <!-- Footer Component -->
  <div class="page__footer" data-component="footer"></div>
  
  <!-- Scripts -->
  <script src="js/component-loader.js"></script>
  <script src="js/main.js"></script>
</body>
</html>
```

## Customizing Components

To customize an existing component:

1. Open the component file in the `components/` directory
2. Make your changes to the HTML structure
3. Add or modify properties as needed
4. Update the CSS in the appropriate CSS file

To create a new component:

1. Create a new HTML file in the `components/` directory
2. Define the component's HTML structure
3. Use `{{propertyName}}` for dynamic properties
4. Add any component-specific JavaScript
5. Add CSS for the component in `css/components.css`

## CSS Structure

The CSS is organized into several files:

- `base.css` - Reset, variables, and foundational styles
- `components.css` - Styles for reusable components
- `layout.css` - Page layouts and section styles
- `main.css` - Imports all other CSS files

This structure makes it easy to find and update styles for specific parts of the website.

## JavaScript Features

The website includes several JavaScript features:

- Component loading system
- Custom cursor with optimized performance
- Smooth animations using GSAP
- Video handling with fallbacks
- Mobile detection and adaptation
- Navigation handling
- Red flag popup functionality

## Deployment

To deploy the website:

1. Build the project (no build step required, as this is vanilla HTML/CSS/JS)
2. Upload all files to your hosting provider (e.g., Cloudflare)
3. Ensure all paths are correct (relative paths are used throughout)
4. Test the website on different devices and browsers

For Cloudflare specifically:
1. Log in to your Cloudflare account
2. Go to the Pages section
3. Create a new project or update an existing one
4. Upload your files or connect to your Git repository
5. Deploy the website

## Issues Fixed in This Version

- Mouse cursor performance issues
- Hero video loading and overlay problems
- Orange color on page breaks removed
- Spacing in red flag text fixed
- Consistent header/footer across all pages
- About page loading issues resolved
- Services page loading logo and mountain image issues fixed
- Mobile vs desktop differences for red flag popup addressed