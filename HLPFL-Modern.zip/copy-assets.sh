#!/bin/bash

# Script to copy assets from the old HLPFL site to the new component-based site
# Usage: ./copy-assets.sh /path/to/old/site

# Check if source directory is provided
if [ -z "$1" ]; then
  echo "Error: Please provide the path to the old site."
  echo "Usage: ./copy-assets.sh /path/to/old/site"
  exit 1
fi

OLD_SITE=$1
NEW_SITE="."

echo "Copying assets from $OLD_SITE to $NEW_SITE..."

# Create necessary directories if they don't exist
mkdir -p images
mkdir -p images/favicon
mkdir -p fonts

# Copy images
echo "Copying images..."
if [ -d "$OLD_SITE/images" ]; then
  cp -r "$OLD_SITE/images/"* images/
  echo "Images copied successfully."
else
  echo "Warning: Images directory not found in old site."
fi

# Copy favicon files
echo "Copying favicon files..."
if [ -d "$OLD_SITE/images/favicon" ]; then
  cp -r "$OLD_SITE/images/favicon/"* images/favicon/
  echo "Favicon files copied successfully."
else
  echo "Warning: Favicon directory not found in old site."
fi

# Copy videos
echo "Copying videos..."
if [ -d "$OLD_SITE/videos" ]; then
  mkdir -p videos
  cp -r "$OLD_SITE/videos/"* videos/
  echo "Videos copied successfully."
else
  echo "Warning: Videos directory not found in old site."
fi

# Copy fonts
echo "Copying fonts..."
if [ -d "$OLD_SITE/fonts" ]; then
  cp -r "$OLD_SITE/fonts/"* fonts/
  echo "Fonts copied successfully."
else
  echo "Warning: Fonts directory not found in old site."
fi

# Copy any other assets
echo "Copying other assets..."
if [ -d "$OLD_SITE/assets" ]; then
  mkdir -p assets
  cp -r "$OLD_SITE/assets/"* assets/
  echo "Other assets copied successfully."
else
  echo "Info: No additional assets directory found."
fi

echo "Asset copying complete!"
echo "Next steps:"
echo "1. Review the copied assets and ensure they're in the correct locations"
echo "2. Update references in your HTML files if necessary"
echo "3. Follow the MIGRATION-GUIDE.md for further instructions"