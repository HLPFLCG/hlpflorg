/**
 * Component Loader System
 * This system allows for easy reuse of components across pages
 */

class ComponentLoader {
  constructor() {
    this.loadedComponents = new Map();
    this.componentPromises = new Map();
    this.componentData = {};
  }

  /**
   * Initialize the component loader
   */
  init() {
    // Find all component placeholders in the document
    document.querySelectorAll('[data-component]').forEach(placeholder => {
      this.loadComponent(placeholder);
    });

    // Set up global data that can be accessed by components
    this.componentData = {
      currentYear: new Date().getFullYear(),
      // Add more global data as needed
    };

    // Listen for dynamic component additions
    document.addEventListener('component:load', (e) => {
      if (e.detail && e.detail.element) {
        this.loadComponent(e.detail.element);
      }
    });
  }

  /**
   * Load a component into a placeholder element
   * @param {HTMLElement} placeholder - The element to load the component into
   */
  loadComponent(placeholder) {
    const componentName = placeholder.getAttribute('data-component');
    const componentProps = this.parseProps(placeholder);
    
    // Skip if no component name is provided
    if (!componentName) return;
    
    // Path to the component file
    const componentPath = `components/${componentName}.html`;
    
    // Check if we're already loading this component
    if (this.componentPromises.has(componentPath)) {
      this.componentPromises.get(componentPath)
        .then(html => this.renderComponent(placeholder, html, componentProps));
      return;
    }
    
    // Load the component
    const promise = fetch(componentPath)
      .then(response => {
        if (!response.ok) {
          throw new Error(`Failed to load component: ${componentName}`);
        }
        return response.text();
      })
      .then(html => {
        this.loadedComponents.set(componentPath, html);
        this.renderComponent(placeholder, html, componentProps);
        return html;
      })
      .catch(error => {
        console.error(error);
        placeholder.innerHTML = `<div class="component-error">Failed to load component: ${componentName}</div>`;
      });
    
    this.componentPromises.set(componentPath, promise);
  }

  /**
   * Parse component properties from data attributes
   * @param {HTMLElement} element - The element with data attributes
   * @returns {Object} - Object containing all props
   */
  parseProps(element) {
    const props = {};
    
    // Get all data attributes that start with 'data-prop-'
    Array.from(element.attributes)
      .filter(attr => attr.name.startsWith('data-prop-'))
      .forEach(attr => {
        // Convert data-prop-title to title
        const propName = attr.name.replace('data-prop-', '');
        props[propName] = attr.value;
      });
    
    return props;
  }

  /**
   * Render a component with its properties
   * @param {HTMLElement} placeholder - The element to render into
   * @param {string} html - The component HTML template
   * @param {Object} props - The component properties
   */
  renderComponent(placeholder, html, props) {
    // Replace template variables with props
    let renderedHtml = html;
    
    // Replace component props (e.g., {{title}})
    Object.entries(props).forEach(([key, value]) => {
      const regex = new RegExp(`{{${key}}}`, 'g');
      renderedHtml = renderedHtml.replace(regex, value);
    });
    
    // Replace global data (e.g., {{$currentYear}})
    Object.entries(this.componentData).forEach(([key, value]) => {
      const regex = new RegExp(`{{\\$${key}}}`, 'g');
      renderedHtml = renderedHtml.replace(regex, value);
    });
    
    // Insert the rendered HTML
    placeholder.innerHTML = renderedHtml;
    
    // Execute any scripts in the component
    placeholder.querySelectorAll('script').forEach(oldScript => {
      const newScript = document.createElement('script');
      Array.from(oldScript.attributes).forEach(attr => {
        newScript.setAttribute(attr.name, attr.value);
      });
      newScript.textContent = oldScript.textContent;
      oldScript.parentNode.replaceChild(newScript, oldScript);
    });
    
    // Look for nested components
    placeholder.querySelectorAll('[data-component]').forEach(nestedPlaceholder => {
      this.loadComponent(nestedPlaceholder);
    });
    
    // Dispatch event when component is loaded
    placeholder.dispatchEvent(new CustomEvent('component:loaded', {
      bubbles: true,
      detail: { componentName: placeholder.getAttribute('data-component') }
    }));
  }
}

// Initialize the component loader when the DOM is ready
document.addEventListener('DOMContentLoaded', () => {
  window.componentLoader = new ComponentLoader();
  window.componentLoader.init();
});