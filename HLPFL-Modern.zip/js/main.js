/**
 * Main JavaScript for HLPFL website
 * Handles animations, interactions, and UI functionality
 */

// Main initialization function
function initializeWebsite() {
  // Initialize components first
  if (window.componentLoader) {
    // Components are already initialized by component-loader.js
    console.log('Component system initialized');
  }

  // Initialize all features
  initPreloader();
  initCustomCursor();
  initScrollAnimations();
  initVideoHandling();
  initMobileDetection();
  initNavigation();
  initRedFlagPopup();
}

// Preloader functionality
function initPreloader() {
  const preloader = document.querySelector('.preloader');
  if (!preloader) return;

  // Hide preloader after content is loaded
  window.addEventListener('load', () => {
    // Short delay to ensure everything is ready
    setTimeout(() => {
      preloader.classList.add('fade-out');
      
      // Remove preloader from DOM after animation
      setTimeout(() => {
        preloader.style.display = 'none';
      }, 500);
    }, 300);
  });
}

// Custom cursor implementation - optimized for performance
function initCustomCursor() {
  const cursor = document.querySelector('.cursor');
  if (!cursor) return;

  // Variables for cursor position
  let mouseX = 0;
  let mouseY = 0;
  let cursorX = 0;
  let cursorY = 0;
  
  // Use requestAnimationFrame for smooth performance
  let animationFrame;
  
  // Track mouse position
  document.addEventListener('mousemove', (e) => {
    mouseX = e.clientX;
    mouseY = e.clientY;
    
    // Show cursor when mouse moves
    cursor.classList.add('visible');
    
    // Cancel any existing animation frame to prevent buildup
    if (animationFrame) {
      cancelAnimationFrame(animationFrame);
    }
    
    // Start animation loop
    if (!animationFrame) {
      animateCustomCursor();
    }
  });
  
  // Hide cursor when mouse leaves the window
  document.addEventListener('mouseout', () => {
    cursor.classList.remove('visible');
  });
  
  // Add hover effect for interactive elements
  document.addEventListener('mouseover', (e) => {
    // Check if the element or its parents have the hoverable class
    let target = e.target;
    let isHoverable = false;
    
    while (target && target !== document.body) {
      if (target.tagName === 'A' || 
          target.tagName === 'BUTTON' || 
          target.classList.contains('hoverable')) {
        isHoverable = true;
        break;
      }
      target = target.parentElement;
    }
    
    if (isHoverable) {
      cursor.classList.add('active');
    } else {
      cursor.classList.remove('active');
    }
  });
  
  // Smooth cursor animation using lerp (linear interpolation)
  function animateCustomCursor() {
    // Calculate the distance between current position and target
    const dx = mouseX - cursorX;
    const dy = mouseY - cursorY;
    
    // Apply easing (adjust the 0.2 value for different smoothness)
    cursorX += dx * 0.2;
    cursorY += dy * 0.2;
    
    // Apply the position using transform for better performance
    cursor.style.transform = `translate3d(${cursorX}px, ${cursorY}px, 0)`;
    
    // Continue animation only if there's significant movement
    if (Math.abs(dx) > 0.1 || Math.abs(dy) > 0.1) {
      animationFrame = requestAnimationFrame(animateCustomCursor);
    } else {
      // Set final position and stop animation
      cursor.style.transform = `translate3d(${mouseX}px, ${mouseY}px, 0)`;
      animationFrame = null;
    }
  }
}

// Scroll animations
function initScrollAnimations() {
  // Check if required libraries are loaded
  if (!window.gsap || !window.ScrollTrigger) {
    console.warn('GSAP or ScrollTrigger not loaded. Skipping scroll animations.');
    return;
  }

  // Register ScrollTrigger plugin
  gsap.registerPlugin(ScrollTrigger);

  // Fade-in animations for elements
  gsap.utils.toArray('.fade-in').forEach(element => {
    gsap.from(element, {
      opacity: 0,
      y: 30,
      duration: 0.8,
      scrollTrigger: {
        trigger: element,
        start: 'top 85%',
        once: true
      }
    });
  });

  // Parallax elements
  gsap.utils.toArray('.parallax').forEach(element => {
    const speed = element.dataset.speed || 0.2;
    
    gsap.to(element, {
      y: () => -100 * speed,
      ease: 'none',
      scrollTrigger: {
        trigger: element,
        start: 'top bottom',
        end: 'bottom top',
        scrub: true
      }
    });
  });
}

// Video handling
function initVideoHandling() {
  // Find all video elements with data-autoplay attribute
  document.querySelectorAll('video[data-autoplay]').forEach(video => {
    // Ensure video loads and plays correctly
    video.addEventListener('loadeddata', () => {
      // Remove any overlay that might be blocking the video
      const parent = video.parentElement;
      const overlay = parent.querySelector('.video-overlay');
      
      if (overlay) {
        overlay.style.opacity = '0.5'; // Reduce opacity but don't remove completely
      }
      
      // Play the video
      video.play().catch(err => {
        console.warn('Autoplay prevented:', err);
        
        // Show play button if autoplay is prevented
        if (overlay) {
          overlay.innerHTML += '<button class="video-play-btn"><i class="fas fa-play"></i></button>';
          
          // Add click handler to play video
          const playBtn = overlay.querySelector('.video-play-btn');
          if (playBtn) {
            playBtn.addEventListener('click', () => {
              video.play();
              overlay.style.opacity = '0';
            });
          }
        }
      });
    });
    
    // Handle video loading errors
    video.addEventListener('error', () => {
      console.error('Video failed to load:', video.src);
      video.parentElement.classList.add('video-error');
    });
  });
}

// Mobile detection
function initMobileDetection() {
  const isMobile = window.matchMedia('(max-width: 768px)').matches;
  
  if (isMobile) {
    document.body.classList.add('is-mobile');
    
    // Adjust features for mobile
    document.querySelectorAll('.desktop-only').forEach(el => {
      el.style.display = 'none';
    });
    
    // Enable mobile-specific features
    document.querySelectorAll('.mobile-only').forEach(el => {
      el.style.display = 'block';
    });
  } else {
    document.body.classList.add('is-desktop');
  }
  
  // Listen for orientation changes
  window.addEventListener('resize', () => {
    const newIsMobile = window.matchMedia('(max-width: 768px)').matches;
    
    if (newIsMobile !== isMobile) {
      // Reload the page to apply correct layout
      // This is a simple approach - a more sophisticated one would
      // dynamically adjust the layout without reloading
      window.location.reload();
    }
  });
}

// Navigation handling
function initNavigation() {
  const header = document.querySelector('header');
  const navToggle = document.querySelector('.nav-toggle');
  const navMenu = document.querySelector('.nav-menu');
  
  if (navToggle && navMenu) {
    // Mobile menu toggle
    navToggle.addEventListener('click', () => {
      navToggle.classList.toggle('active');
      navMenu.classList.toggle('active');
      document.body.classList.toggle('menu-open');
    });
    
    // Close menu when clicking outside
    document.addEventListener('click', (e) => {
      if (navMenu.classList.contains('active') && 
          !navMenu.contains(e.target) && 
          !navToggle.contains(e.target)) {
        navToggle.classList.remove('active');
        navMenu.classList.remove('active');
        document.body.classList.remove('menu-open');
      }
    });
  }
  
  // Sticky header
  if (header) {
    let lastScrollTop = 0;
    
    window.addEventListener('scroll', () => {
      const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
      
      // Add sticky class when scrolling down
      if (scrollTop > 50) {
        header.classList.add('sticky');
      } else {
        header.classList.remove('sticky');
      }
      
      // Hide/show header based on scroll direction
      if (scrollTop > lastScrollTop && scrollTop > 200) {
        // Scrolling down & past header height
        header.classList.add('header-hidden');
      } else {
        // Scrolling up
        header.classList.remove('header-hidden');
      }
      
      lastScrollTop = scrollTop;
    });
  }
}

// Red Flag Popup handling
function initRedFlagPopup() {
  const redFlagTrigger = document.querySelector('[data-redflag-trigger]');
  const redFlagPopup = document.querySelector('.redflag-popup');
  const closePopupBtn = document.querySelector('.close-popup');
  
  if (redFlagTrigger && redFlagPopup) {
    // Show popup when trigger is clicked
    redFlagTrigger.addEventListener('click', (e) => {
      e.preventDefault();
      redFlagPopup.classList.add('active');
      document.body.classList.add('popup-open');
    });
    
    // Close popup when close button is clicked
    if (closePopupBtn) {
      closePopupBtn.addEventListener('click', () => {
        redFlagPopup.classList.remove('active');
        document.body.classList.remove('popup-open');
      });
    }
    
    // Close popup when clicking outside
    redFlagPopup.addEventListener('click', (e) => {
      if (e.target === redFlagPopup) {
        redFlagPopup.classList.remove('active');
        document.body.classList.remove('popup-open');
      }
    });
    
    // Show popup automatically on mobile if needed
    const isMobile = window.matchMedia('(max-width: 768px)').matches;
    const shouldShowOnMobile = redFlagPopup.hasAttribute('data-show-on-mobile');
    
    if (isMobile && shouldShowOnMobile) {
      // Show popup after a delay
      setTimeout(() => {
        redFlagPopup.classList.add('active');
        document.body.classList.add('popup-open');
      }, 2000);
    }
  }
}

// Initialize everything when the DOM is ready
document.addEventListener('DOMContentLoaded', initializeWebsite);