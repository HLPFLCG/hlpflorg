# Old vs. New Approach: A Comparison

## Website Architecture Comparison

| Feature | Old Approach | New Component-Based Approach |
|---------|-------------|------------------------------|
| **Code Reusability** | Limited - Header and footer components existed but weren't fully utilized | High - All UI elements are reusable components |
| **Maintenance** | Difficult - Changes needed to be made in multiple files | Easy - Change a component once, updates everywhere |
| **Performance** | Issues with mouse cursor and video loading | Optimized performance with efficient JavaScript |
| **Consistency** | Inconsistent header/footer across pages | Perfect consistency across all pages |
| **Mobile Support** | Inconsistent behavior between mobile and desktop | Responsive design with consistent behavior |
| **Loading Experience** | Issues with loading screens | Smooth, reliable loading with fallbacks |
| **Code Organization** | Mixed concerns, less structured | Clear separation of concerns, well-organized |

## Specific Issues Fixed

### 1. Mouse Cursor Performance

**Old Approach:**
```javascript
document.addEventListener('mousemove', (e) => {
  gsap.to(cursor, {
    x: e.clientX,
    y: e.clientY,
    duration: 0.1
  });
});
```

**New Approach:**
```javascript
// Variables for cursor position
let mouseX = 0;
let mouseY = 0;
let cursorX = 0;
let cursorY = 0;

// Use requestAnimationFrame for smooth performance
let animationFrame;

document.addEventListener('mousemove', (e) => {
  mouseX = e.clientX;
  mouseY = e.clientY;
  
  // Cancel any existing animation frame to prevent buildup
  if (animationFrame) {
    cancelAnimationFrame(animationFrame);
  }
  
  // Start animation loop
  if (!animationFrame) {
    animateCustomCursor();
  }
});

// Smooth cursor animation using lerp (linear interpolation)
function animateCustomCursor() {
  // Calculate the distance between current position and target
  const dx = mouseX - cursorX;
  const dy = mouseY - cursorY;
  
  // Apply easing
  cursorX += dx * 0.2;
  cursorY += dy * 0.2;
  
  // Apply the position using transform for better performance
  cursor.style.transform = `translate3d(${cursorX}px, ${cursorY}px, 0)`;
  
  // Continue animation only if there's significant movement
  if (Math.abs(dx) > 0.1 || Math.abs(dy) > 0.1) {
    animationFrame = requestAnimationFrame(animateCustomCursor);
  } else {
    animationFrame = null;
  }
}
```

### 2. Hero Video Loading

**Old Approach:**
```html
<div class="hero__video-container">
  <video class="hero__video" autoplay muted loop playsinline>
    <source src="video.mp4" type="video/mp4">
  </video>
  <div class="hero__overlay"></div>
</div>
```

**New Approach:**
```html
<div class="hero__video-container">
  <!-- Video with preload attribute to ensure it loads properly -->
  <video class="hero__video" autoplay muted loop playsinline preload="auto" data-autoplay>
    <source src="{{video-src}}" type="video/mp4">
    <!-- Fallback image if video fails to load -->
    <img src="{{fallback-image}}" alt="{{alt-text}}">
  </video>
  <!-- Overlay with reduced opacity -->
  <div class="hero__overlay"></div>
</div>

<script>
  // Script to ensure video loads properly
  document.addEventListener('DOMContentLoaded', () => {
    const video = document.querySelector('.hero__video');
    const overlay = document.querySelector('.hero__overlay');
    
    if (video) {
      // Force video to load
      video.load();
      
      // Check if video can play
      video.addEventListener('canplay', () => {
        // Reduce overlay opacity once video can play
        if (overlay) {
          overlay.style.opacity = '0.5';
        }
      });
      
      // Handle video loading error
      video.addEventListener('error', () => {
        console.error('Video failed to load');
        // Keep overlay visible if video fails
        if (overlay) {
          overlay.style.opacity = '0.7';
        }
      });
    }
  });
</script>
```

### 3. Component Loading System

**Old Approach:**
```javascript
function loadComponent(targetId, componentPath) {
  const target = document.getElementById(targetId);
  if (!target) return;
  
  fetch(componentPath)
    .then(response => response.text())
    .then(html => {
      target.innerHTML = html;
      // Trigger any scripts that need to run after component loads
      const event = new Event('componentLoaded');
      document.dispatchEvent(event);
    })
    .catch(error => console.error('Error loading component:', error));
}
```

**New Approach:**
```javascript
class ComponentLoader {
  constructor() {
    this.loadedComponents = new Map();
    this.componentPromises = new Map();
    this.componentData = {};
  }

  init() {
    // Find all component placeholders in the document
    document.querySelectorAll('[data-component]').forEach(placeholder => {
      this.loadComponent(placeholder);
    });

    // Set up global data that can be accessed by components
    this.componentData = {
      currentYear: new Date().getFullYear(),
      // Add more global data as needed
    };

    // Listen for dynamic component additions
    document.addEventListener('component:load', (e) => {
      if (e.detail && e.detail.element) {
        this.loadComponent(e.detail.element);
      }
    });
  }

  loadComponent(placeholder) {
    const componentName = placeholder.getAttribute('data-component');
    const componentProps = this.parseProps(placeholder);
    
    // Skip if no component name is provided
    if (!componentName) return;
    
    // Path to the component file
    const componentPath = `components/${componentName}.html`;
    
    // Check if we're already loading this component
    if (this.componentPromises.has(componentPath)) {
      this.componentPromises.get(componentPath)
        .then(html => this.renderComponent(placeholder, html, componentProps));
      return;
    }
    
    // Load the component
    const promise = fetch(componentPath)
      .then(response => {
        if (!response.ok) {
          throw new Error(`Failed to load component: ${componentName}`);
        }
        return response.text();
      })
      .then(html => {
        this.loadedComponents.set(componentPath, html);
        this.renderComponent(placeholder, html, componentProps);
        return html;
      })
      .catch(error => {
        console.error(error);
        placeholder.innerHTML = `<div class="component-error">Failed to load component: ${componentName}</div>`;
      });
    
    this.componentPromises.set(componentPath, promise);
  }

  parseProps(element) {
    const props = {};
    
    // Get all data attributes that start with 'data-prop-'
    Array.from(element.attributes)
      .filter(attr => attr.name.startsWith('data-prop-'))
      .forEach(attr => {
        // Convert data-prop-title to title
        const propName = attr.name.replace('data-prop-', '');
        props[propName] = attr.value;
      });
    
    return props;
  }

  renderComponent(placeholder, html, props) {
    // Replace template variables with props
    let renderedHtml = html;
    
    // Replace component props (e.g., {{title}})
    Object.entries(props).forEach(([key, value]) => {
      const regex = new RegExp(`{{${key}}}`, 'g');
      renderedHtml = renderedHtml.replace(regex, value);
    });
    
    // Replace global data (e.g., {{$currentYear}})
    Object.entries(this.componentData).forEach(([key, value]) => {
      const regex = new RegExp(`{{\\$${key}}}`, 'g');
      renderedHtml = renderedHtml.replace(regex, value);
    });
    
    // Insert the rendered HTML
    placeholder.innerHTML = renderedHtml;
    
    // Execute any scripts in the component
    placeholder.querySelectorAll('script').forEach(oldScript => {
      const newScript = document.createElement('script');
      Array.from(oldScript.attributes).forEach(attr => {
        newScript.setAttribute(attr.name, attr.value);
      });
      newScript.textContent = oldScript.textContent;
      oldScript.parentNode.replaceChild(newScript, oldScript);
    });
    
    // Look for nested components
    placeholder.querySelectorAll('[data-component]').forEach(nestedPlaceholder => {
      this.loadComponent(nestedPlaceholder);
    });
    
    // Dispatch event when component is loaded
    placeholder.dispatchEvent(new CustomEvent('component:loaded', {
      bubbles: true,
      detail: { componentName: placeholder.getAttribute('data-component') }
    }));
  }
}
```

## Benefits of the New Approach

1. **Modular Development**: Build pages by combining pre-built components
2. **Consistent Design**: Components ensure consistent look and feel across the site
3. **Easier Maintenance**: Update a component once, changes apply everywhere
4. **Better Performance**: Optimized JavaScript for smoother interactions
5. **Improved User Experience**: Faster loading, better animations, and consistent behavior
6. **Future-Proof**: Easy to add new pages or features by reusing existing components
7. **Mobile-First**: Responsive design that works well on all devices

## How This Helps Your Workflow

1. **Faster Updates**: Need to change the header? Update one file instead of every page
2. **Consistent Branding**: Components ensure your brand elements are consistent
3. **Easier Collaboration**: Clear separation of concerns makes it easier for multiple people to work on the site
4. **Reduced Errors**: Less duplicate code means fewer opportunities for mistakes
5. **Faster Development**: Build new pages quickly by combining existing components

## Technical Improvements

1. **CSS Organization**: Structured CSS with variables for easy customization
2. **Performance Optimization**: Efficient JavaScript for smooth animations
3. **Error Handling**: Better error handling for components and media loading
4. **Mobile Responsiveness**: Consistent behavior across devices
5. **Accessibility**: Improved structure for better accessibility
6. **SEO**: Better semantic structure for improved search engine optimization